﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Pigs : MonoBehaviour {
	
	public float maxSpeed = 20;
    public float midSpeed = 10;//不同速度make different hurt
	public float minSpeed = 5;
	public float HP_Max = 100;

	private SpriteRenderer render;

	public Sprite hurt;

	public GameObject boom;
	public GameObject score;

    public bool _Fire_State;
    public bool _Ice_State;
    public bool _Thunder_State;

    public bool isMaster = false;


    public float Resistence_Fire = 0;
    public float Resistence_Ice= 0;
    public float Resistence_Thunder = 0;

    public float Arrow_Dmg_Fire = 0;
    public float Arrow_Dmg_Ice = 0;
    public float Arrow_Dmg_Thunder = 0;

    public float Max_damage = 50;
    public float Mid_damage = 30;
    public float Min_damage = 10;

    float Fire_damage = 0;
    float Ice_damage = 0;
    float Thunder_damage = 0;
    float All_damage = 0;

    private void Awake(){
		render = GetComponent<SpriteRenderer> ();
	}


	private void OnCollisionEnter2D(Collision2D collision){
        
        if (isMaster)
        {
            Calculate();
            if (collision.relativeVelocity.magnitude > maxSpeed)
            {
                HP_Max = HP_Max - All_damage - Max_damage;
            }
            else if ((collision.relativeVelocity.magnitude) > midSpeed &&
              (collision.relativeVelocity.magnitude < maxSpeed))
            {

                HP_Max = HP_Max - All_damage - Mid_damage;

            }
            else if ((collision.relativeVelocity.magnitude) > minSpeed &&
             (collision.relativeVelocity.magnitude < midSpeed))
            {
                HP_Max = HP_Max - All_damage - Min_damage;

            }
            else if ((collision.relativeVelocity.magnitude) < minSpeed )
            {

                HP_Max = HP_Max - 0;

            }
            if (HP_Max <= 0)
            {
                Dead();
            }
        }
    }
	void Dead(){
		if (isMaster) {
			GameManager._instance.pig.Remove (this);
		}
		Destroy (gameObject);
		Instantiate (boom, transform.position, Quaternion.identity);
		GameObject go = Instantiate (score, transform.position + new Vector3(0,0.5f,0), Quaternion.identity);
		Destroy (go, 1.5f);
	}
	private void OnTriggleEnter2D(Collision2D collision){
        
    }
    public void Calculate() {
        /// <summary>
        /// 伤害计算
        /// </summary>
        if (_Fire_State)
        {
            Arrow_Dmg_Fire += Arrow_Dmg_Fire;
        }
        if (_Ice_State)
        {
            Arrow_Dmg_Fire += Arrow_Dmg_Ice;
        }
        if (_Thunder_State)
        {
            Arrow_Dmg_Fire += Arrow_Dmg_Thunder;
        }

        Fire_damage = Arrow_Dmg_Fire - Resistence_Fire;
        Ice_damage = Arrow_Dmg_Ice - Resistence_Ice;
        Thunder_damage = Arrow_Dmg_Thunder - Resistence_Thunder;
        All_damage = Fire_damage + Ice_damage + Thunder_damage;
    }
    void Start () {
		
	}
	// Update is called once per frame
	void Update () {
		
	}
}
