﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class DragAndThrow : MonoBehaviour, IPointerDownHandler, IPointerUpHandler, IDragHandler, IPointerEnterHandler, IPointerExitHandler
{
    [SerializeField]
    float launchForce;
    /// <summary>
    /// 速度的三个档位
    /// maxForce/2 /4 /8 为三个速度
    /// </summary>
    [SerializeField]
    float maxForce;

    [SerializeField]
    float midForce;

    [SerializeField]
    float minForce;

    Vector3 downPos;

    private SpriteRenderer render;
    private Rigidbody2D rg;
    /// <summary>
    /// 三种状态
    /// </summary>
    public Sprite Fire_State;
    public Sprite Ice_State;
    public Sprite Thunder_State;

    public bool _Fire_State;
    public bool _Ice_State;
    public bool _Thunder_State;
    /// <summary>
    /// 时间
    /// </summary>
    public float Time_Max = 100;
    public float Time_Pers = 1;
    /// <summary>
    /// 能量
    /// </summary>
    public int Arrow_Energy_Max = 100;
    public int Arrow_Power_decrease_Pers = 1;
    public Text Energy;

    public float Arrow_Dmg_Fire;
    public float Arrow_Dmg_Ice;
    public float Arrow_Dmg_Thunder;

    Ray flyRay;

    void OnDrawGizmos()
    {
        Gizmos.color = Color.red;
        Gizmos.DrawRay(flyRay);
    }
    /// <summary>
    /// 空中暂停
    /// </summary>
    public void OnPointerDown(PointerEventData eventData)
    {
        downPos = Camera.main.ScreenToWorldPoint(eventData.position);
        GetComponent<Rigidbody2D>().velocity = Vector2.zero;
    }
    /// <summary>
    /// 不同速度
    /// </summary>
    public void OnPointerUp(PointerEventData eventData)
    {
        var upPos = Camera.main.ScreenToWorldPoint(eventData.position);
        var dir = (downPos - upPos) * launchForce;

        if (dir.sqrMagnitude > maxForce)
            dir = dir.normalized * maxForce/2;
        if (dir.sqrMagnitude < maxForce && dir.sqrMagnitude > midForce)
            dir = dir.normalized * maxForce/4;
        if (dir.sqrMagnitude < midForce)
            dir = dir.normalized * maxForce/8;



        GetComponent<Rigidbody2D>().AddForce(dir, ForceMode2D.Impulse);
    }

    /// <summary>
    /// 计时器
    /// </summary>
    void Update()
    {
        if (Time_Max > 0)
        {
            Time_Pers -= Time.deltaTime;
            if (Time_Pers <= 0)
            {
                Time_Pers += 1;
                Time_Max = Time_Max - Time_Pers;
                Energy.text = string.Format("{0:D2}:{1:D2}", (int)Time_Max / 60, (int)Time_Max % 60);
                Arrow_Energy_Max = Arrow_Energy_Max - Arrow_Power_decrease_Pers;
            }
        }
    }
    public void OnDrag(PointerEventData eventData)
    {
        flyRay = new Ray(transform.position, Camera.main.ScreenToWorldPoint(eventData.position) - downPos);
    }
    /// <summary>
    /// 子弹时间
    /// </summary>
    public void OnPointerEnter(PointerEventData eventData)
    {
        Time.fixedDeltaTime = 0.0001f;
        Time.timeScale = 0.02f;
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        Time.fixedDeltaTime = 0.02f;
        Time.timeScale = 1f;
    }
    public void Statement() {
        if (GameManager._instance.Fire_State) {
            render.sprite = Fire_State;
        }
        if (GameManager._instance.Ice_State)
        {
            render.sprite = Ice_State;
        }
        if (GameManager._instance.Thunder_State)
        {
            render.sprite = Thunder_State;
        }
    }
 
}
