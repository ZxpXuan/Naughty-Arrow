﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour {
	public List<Birds> bird;
	public List <Pigs> pig;
	public static GameManager _instance;
	private Transform originPos;//初始化位置

	private void Awake(){
		_instance = this;
	}

	private void Start(){
		Initialized ();
	}
	private void Initialized(){
		for (int i = 0; i < bird.Count; i++) {
			if (i == 0) {//第一只bird
				bird [i].enabled = true;
				bird [i].sp.enabled = true;
			} else {
				bird [i].enabled = false;
				bird [i].sp.enabled = false;
			}
		}
	}
	///<summary>
	/// 判定you xi luo ji.
	/// </summary>
	public void NextBird(){
		if (pig.Count > 0) {
			if (bird.Count > 0) {
				//next bird
				Initialized();
			} else {
				//lose
			}
		} else {
			//win
		}
	}
}
