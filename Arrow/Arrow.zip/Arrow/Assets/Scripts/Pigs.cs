﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Pigs : MonoBehaviour {
	
	public float maxSpeed = 10;//不同速度make different hurt
	public float minSpeed = 5;
	public float hp = 100;
	public bool isPig = false;//make different anamy

	private SpriteRenderer render;

	public Sprite hurt;

	public GameObject boom;
	public GameObject score;

	private void Awake(){
		render = GetComponent<SpriteRenderer> ();
	}


	private void OnCollisionEnter2D(Collision2D collision){
		if (collision.relativeVelocity.magnitude > maxSpeed) {
			
			render.sprite = hurt;
			hp = hp - 80;

		} else if ((collision.relativeVelocity.magnitude) > minSpeed &&
			(collision.relativeVelocity.magnitude < maxSpeed)) {

			render.sprite = hurt;
			 
			hp = hp - 20;

		}
		if (hp <= 0) {
			Dead ();
		}
	}
	void Dead(){
		if (isPig) {
			GameManager._instance.pig.Remove (this);
		}
		Destroy (gameObject);
		Instantiate (boom, transform.position, Quaternion.identity);
		GameObject go = Instantiate (score, transform.position + new Vector3(0,0.5f,0), Quaternion.identity);
		Destroy (go, 1.5f);
	}
	private void OnTriggleEnter2D(Collider2D collision){
		
	}
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
